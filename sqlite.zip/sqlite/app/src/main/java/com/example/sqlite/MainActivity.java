package com.example.sqlite;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    EditText name, contact, dob;
    Button btn, btnupdate, btndelete, btnview;
    DBHelper db = new DBHelper(this);
    ListView listView;
    ArrayList<String> arrayList=new ArrayList<>();
    ArrayList<String> namelist=new ArrayList<>();
    String getdata;
    TextView head;
    ArrayAdapter<String> arrayAdapter;
    SearchView searchview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name = findViewById(R.id.name);
        contact = findViewById(R.id.contact);
        dob = findViewById(R.id.dob);
        btn = findViewById(R.id.btn);
        head=findViewById(R.id.head);
        btndelete = findViewById(R.id.btndelete);
        searchview=findViewById(R.id.searchview);

        listView=findViewById(R.id.listview);
        btnupdate = findViewById(R.id.btnupdate);
        btnview = findViewById(R.id.btnview);
        arrayAdapter=new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,arrayList);
        listView.setAdapter(arrayAdapter);

        searchview.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                String[] separator = arrayList.get(0).split(":");
//                Toast.makeText(MainActivity.this, "1" + separator[0] + "\n2"
//                        + separator[1] + "\n3" + separator[2] + "\n4" + separator[3] + "\n5"
//                        + separator[4] + "\n6" + separator[5], Toast.LENGTH_SHORT).show();
                Toast.makeText(MainActivity.this, separator.length, Toast.LENGTH_SHORT).show();
                return false;
            }


            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nameTXT = name.getText().toString();
                String contactTXT = contact.getText().toString();
                String dobTXT = dob.getText().toString();

                Boolean checkinsertdata = db.insertuserdata(nameTXT, contactTXT, dobTXT);
                if (checkinsertdata == true)
                    Toast.makeText(MainActivity.this, "New Data Inserted", Toast.LENGTH_SHORT)
                            .show();
                else
                    Toast.makeText(MainActivity.this, "New Data Not Inserted", Toast.LENGTH_SHORT)
                            .show();
            }
        });
        btnupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nameTXT = name.getText().toString();
                String contactTXT = contact.getText().toString();
                String dobTXT = dob.getText().toString();

                Boolean checkupdatedata = db.updatedata(nameTXT, contactTXT, dobTXT);
                if (checkupdatedata == true)
                    Toast.makeText(MainActivity.this, "Entry Updated", Toast.LENGTH_SHORT)
                            .show();
                else
                    Toast.makeText(MainActivity.this, " Data Not Updated", Toast.LENGTH_SHORT)
                            .show();
            }
        });
        btndelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nameTXT = name.getText().toString();


                Boolean checkdeletedata = db.deletedata(nameTXT);
                if (checkdeletedata == true)
                    Toast.makeText(MainActivity.this, "Entry Deleted", Toast.LENGTH_SHORT)
                            .show();
                else
                    Toast.makeText(MainActivity.this, " Data Not Deleted", Toast.LENGTH_SHORT)
                            .show();
            }
        });
        btnview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor res = db.getdata();
                if (res.getCount() == 0) {
                    Toast.makeText(MainActivity.this, "No Data Exsist", Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (res.moveToNext()) {
                arrayList.add("Name:" + res.getString(0) + "\n"+"Contact:" +
                        res.getString(1) + "\n"+
                        "DOB:" + res.getString(2) + "\n\n");
                    buffer.append("Name:" + res.getString(0) + "\n");
                    buffer.append("Contact:" + res.getString(1) + "\n");
                    buffer.append("DOB:" + res.getString(2) + "\n");

                }
                arrayAdapter.notifyDataSetChanged();
                Toast.makeText(MainActivity.this, buffer.toString(), Toast.LENGTH_SHORT).show();

//                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
//                builder.setCancelable(true);
//                builder.setTitle("User Data");
//                builder.setMessage(buffer.toString());
//                builder.show();
            }
        });
    }
    }
