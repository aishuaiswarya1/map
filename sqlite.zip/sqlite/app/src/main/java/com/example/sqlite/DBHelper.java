package com.example.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    private static final String name = "Userdata";
    private final Object version=1;

    public DBHelper(@Nullable Context context) {
        super(context, "Userdata", null ,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create Table Userdetails(name primary key,contact TEXT,dob TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
db.execSQL("drop Table if exists Userdetails");
    }
    public Boolean insertuserdata(String name,String contact,String dob){
        SQLiteDatabase DB=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("name",name);
        values.put("contact",contact);
        values.put("dob",dob);
        long result=DB.insert("Userdetails",null,values);
        if(result==-1){
            return false;
        }else {
            return true;
        }
    }
    public Boolean updatedata(String name,String contact,String dob) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        Cursor cursor = DB.rawQuery("Select * from Userdetails where name = ?", new String[]{name});
        values.put("contact", contact);
        values.put("dob", dob);
        if(cursor.getCount()>0) {
            long result = DB.update(" Userdetails", values, "name=?", new String[]{name});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        }

    else{
          return false;
        }
    }

    public Boolean deletedata(String name) {
        SQLiteDatabase DB = this.getWritableDatabase();

        Cursor cursor = DB.rawQuery("Select * from Userdetails where name = ?", new String[]{name});

        if (cursor.getCount() > 0) {

            long result = DB.delete("Userdetails", "name=?", new String[]{name});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        }else
        {
            return false;
        }
    }
    public Cursor getdata() {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from Userdetails ",null );
    return cursor;
    }
}